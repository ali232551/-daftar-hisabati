@echo off
setlocal EnableExtensions
set GRADLE_VERSION=8.7
set WRAPPER_HOME=%USERPROFILE%\.gradle\custom-wrapper\gradle-%GRADLE_VERSION%
set GRADLE_EXE=%WRAPPER_HOME%\bin\gradle.bat
if not exist "%GRADLE_EXE%" (
  echo Downloading Gradle %GRADLE_VERSION% for the first build...
  set ZIP=%TEMP%\gradle-%GRADLE_VERSION%-bin.zip
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%TEMP%\gradle-%GRADLE_VERSION%-bin.zip'; New-Item -ItemType Directory -Force -Path '%USERPROFILE%\.gradle\custom-wrapper' | Out-Null; Expand-Archive -LiteralPath '%TEMP%\gradle-%GRADLE_VERSION%-bin.zip' -DestinationPath '%USERPROFILE%\.gradle\custom-wrapper' -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_EXE%" %*
exit /b %ERRORLEVEL%
