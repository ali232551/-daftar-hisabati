package com.daftar.hisabat

import android.app.Activity
import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.OutputStreamWriter

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var printWebView: WebView? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingContent: String? = null
    private var pendingMime: String = "application/json"
    private var pendingFileName: String = "daftar-hisabati-backup.json"
    private val chooseFileCode = 101
    private val saveFileCode = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.setSupportMultipleWindows(false)
        webView.addJavascriptInterface(AndroidBridge(), "Android")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                startActivityForResult(intent, chooseFileCode)
                return true
            }
        }
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun saveBackup(content: String) {
            if (content.isBlank()) {
                runOnUiThread { Toast.makeText(this@MainActivity, "النسخة الاحتياطية فارغة، لم يتم حفظها", Toast.LENGTH_LONG).show() }
                return
            }
            saveTextFile(content, "daftar-hisabati-backup.json", "application/json")
        }

        @JavascriptInterface
        fun openExternal(url: String) {
            runOnUiThread {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                catch (e: Exception) { Toast.makeText(this@MainActivity, "تعذر فتح واتساب", Toast.LENGTH_LONG).show() }
            }
        }

        @JavascriptInterface
        fun sendSms(phone: String, body: String) {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phone))
                    intent.putExtra("sms_body", body)
                    startActivity(intent)
                } catch (e: Exception) { Toast.makeText(this@MainActivity, "تعذر فتح الرسائل", Toast.LENGTH_LONG).show() }
            }
        }

        @JavascriptInterface
        fun printHtml(html: String, documentTitle: String) {
            runOnUiThread {
                try {
                    val printView = WebView(this@MainActivity)
                    printWebView = printView
                    printView.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                            val adapter = view?.createPrintDocumentAdapter(documentTitle)
                            if (adapter != null) {
                                manager.print(
                                    documentTitle,
                                    adapter,
                                    PrintAttributes.Builder()
                                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                        .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                                        .build()
                                )
                            }
                        }
                    }
                    printView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر فتح نافذة الطباعة", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun saveTextFile(content: String, fileName: String, mimeType: String) {
            runOnUiThread {
                pendingContent = content
                pendingFileName = fileName
                pendingMime = mimeType
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = mimeType
                    putExtra(Intent.EXTRA_TITLE, fileName)
                }
                startActivityForResult(intent, saveFileCode)
            }
        }
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == chooseFileCode) {
            val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        } else if (requestCode == saveFileCode) {
            if (resultCode == RESULT_OK && data?.data != null && pendingContent != null) {
                try {
                    val content = pendingContent ?: throw IllegalStateException("لا توجد بيانات للتصدير")
                    if (content.isBlank()) throw IllegalStateException("بيانات النسخة الاحتياطية فارغة")
                    val bytes = content.toByteArray(Charsets.UTF_8)
                    val output = contentResolver.openOutputStream(data.data!!, "wt")
                        ?: throw IllegalStateException("تعذر فتح الملف للكتابة")
                    output.use { stream ->
                        stream.write(bytes)
                        stream.flush()
                    }
                    val verify = contentResolver.openInputStream(data.data!!)?.use { it.readBytes().size } ?: 0
                    if (verify <= 0 || verify != bytes.size) throw IllegalStateException("تم إنشاء ملف فارغ أو غير مكتمل")
                    Toast.makeText(this, "تم حفظ النسخة الاحتياطية بنجاح (${verify} بايت)", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "فشل حفظ النسخة الاحتياطية: ${e.message ?: "خطأ غير معروف"}", Toast.LENGTH_LONG).show()
                }
            } else if (requestCode == saveFileCode && resultCode != RESULT_OK) {
                Toast.makeText(this, "تم إلغاء حفظ النسخة الاحتياطية", Toast.LENGTH_SHORT).show()
            }
            pendingContent = null
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        printWebView?.destroy()
        printWebView = null
        if (this::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
