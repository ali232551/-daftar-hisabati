plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.daftar.hisabat"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.daftar.hisabat"
        minSdk = 23
        targetSdk = 35
        versionCode = 12
        versionName = "1.1.8"
    }

    // Keep Java and Kotlin bytecode targets aligned on JDK 17.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
