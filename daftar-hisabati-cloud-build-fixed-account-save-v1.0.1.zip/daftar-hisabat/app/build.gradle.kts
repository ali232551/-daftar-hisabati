plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.daftar.hisabat"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.daftar.hisabat"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.0.1"
    }
}
